<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Protest+Strike&size=25&duration=600&pause=600&color=BBFFFB&random=false&width=435&lines=+Hi++%E1%95%95(+%D5%9E+%E1%97%9C+%D5%9E+)%E1%95%97+𝗜'𝗠+𝗦𝗨𝗭𝗭𝗬[■■■■■■■■■■]100%............+;A+Multi-fuctional+𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣+𝗕𝗢𝗧;+++++𝗕𝗬+𝗦𝗨𝗭𝗭𝗬+𝗧𝗘𝗖𝗛" alt="Typing SVG" /></a>

<a href="https://www.youtube.com/@SuzzyTech"><img title="Suzzy Tech Youtube Channel" src="https://img.shields.io/badge/Suzzy Tech Youtube Channel-h?color=blue&style=for-the-badge&logo=stacklike"></a>


<a href="https://whatsapp.com/channel/0029VafW1f44o7qD1ZwJWW3P"><img title="SUPPORT CHANNEL" src="https://img.shields.io/badge/SUPPORT CHANNEL-h?color=darkgreen&style=for-the-badge&logo=whatsapp"></a>

<a href="https://github.com/Kingdragony/TYRAX/fork"><img title="FORK REPO" src="https://img.shields.io/badge/FORK REPO-h?color=black&style=for-the-badge&logo=stackshare"></a>


<a href="https://tigercodes-d2affec7cdbf.herokuapp.com/pair"><img title="PAIRING CODE" src="https://img.shields.io/badge/PAIR CODE-h?color=black&style=for-the-badge&logo=stacklike"></a>    
  
𝗛𝗘𝗥𝗢𝗞𝗨 𝗕𝗨𝗜𝗟𝗗𝗣𝗔𝗖𝗞𝗦.
                               
 ```bash
heroku/nodejs
```
```bash
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest

 ````
```bash
https://github.com/clhuang/heroku-buildpack-webp-binaries.git

```
<a href="https://www.youtube.com/@SuzzyTech"><img title="DEPLOYMENT TUTORIALS" src="https://img.shields.io/badge/DEPLOYMENT TUTORIALS-h?color=red&style=for-the-badge&logo=YouTube"></a>

𝖜𝖍𝖆𝖙𝖘𝖆𝖕𝖕𝖇𝖔𝖙 𝖉𝖊𝖛𝖊𝖑𝖔𝖕𝖊𝖉 𝖇𝖞 𝕬𝖗𝖑𝖔𝖉𝖗𝖆𝖌𝖔𝖓.
